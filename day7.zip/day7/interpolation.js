var txt="HCL";

var year =2019;

var msg=`Training is at ${txt} in the year of ${year}`;

var obj={
    "width":100,
    "height":200,
    "getArea":function(){
        return this.width*this.height;
    },
    "print":function(){
        var txt=`[Rectangle---- width ${this.width} height ${this.height} Area : ${this.getArea()}]`;
        console.log(txt)
    }

}

console.log(msg);
obj.print();