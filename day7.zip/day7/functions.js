var f=new Function("a","b", "console.log(a); console.log(b);return a*b");

console.log(f(10,20));