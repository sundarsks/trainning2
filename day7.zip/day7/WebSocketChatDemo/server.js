var WebSocket = require("ws");

const server = new WebSocket.Server({ port: 9000 });


var allClients = [];
var nickNames = []
console.log("Server Initializing");

server.on('connection', f1);

function f1(socket) {
    // socket.on("message", f2);
    // socket.send(" Hello from server");
    console.log("one client connected...");
    allClients.push(socket);
    console.log("Number of clients connected: " + allClients.length);
    socket.on("message", f2);
    //socket.send("Welcome you are connected to server now");
}

function f2(message) {
    var action = message.substr(0, 4);
    console.log(action);
    var result = message.toUpperCase();
    console.log(message)
    var parseInput = JSON.parse(message.substr(5));
    console.log(parseInput);
    if (action == 'join') {
        if (parseInput.name && parseInput.timeOfLogging) {
            nickNames.push(parseInput.name);
            console.log(parseInput.timeOfLogging);
        }
    }
    console.log("Sending to clients : " + result);
    for (i = 0; i < allClients.length; i++) {
        //allClients[i].send(result);
        if (action == 'join') {
            var obj = {
                "currentUsers": nickNames,

            }
            var userListstr = JSON.stringify(obj);
            allClients[i].send(userListstr)
            
        }

        if(action == 'chat'){
            var replyObj = parseInput;
            var resultObj = {
                "nick":replyObj.nickName,
                "msg":replyObj.charData
            }

            var resultStr = JSON.stringify(resultObj);
            allClients[i].send(resultStr)

        }
    }
}

function ChatUser(n) {
    this.name = n;
    this.timeOfLogging = new Date();
}

function ChatMessage(n, m) {
    this.nickName = n;
    this.charData = m;
    this.timeOfMessage = new Date();
}






